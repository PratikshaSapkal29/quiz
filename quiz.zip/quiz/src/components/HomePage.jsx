import React from 'react';

const HomePage = () => {
  return (
    <div className="bg-gradient-to-r from-blue-900 via-gray-800 to-blue-600 h-screen flex justify-center items-center">
      <div className="text-center text-white">
        <h1 className="text-4xl font-bold mb-6">Welcome to the Quiz App</h1>
        <p className="text-lg mb-6">Test your frontend development knowledge!</p>
      </div>
    </div>
  );
};

export default HomePage;
