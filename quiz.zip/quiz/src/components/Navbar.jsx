import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-blue-900 p-4">
      <div className="container mx-auto flex justify-between">
        <h1 className="text-white text-2xl font-bold">Quiz App</h1>
        <div>
          <Link to="/" className="text-white mx-4 hover:underline">
            Home
          </Link>
          <Link to="/quiz-list" className="text-white mx-4 hover:underline">
            Quizzes
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

