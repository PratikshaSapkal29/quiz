import React from 'react';
import { Link } from 'react-router-dom';

const QuizList = () => {
  const quizzes = [
    {
      id: 1,
      title: 'React Basics',
      description: 'Test your knowledge of React fundamentals.',
    },
    {
      id: 2,
      title: 'JavaScript Essentials',
      description: 'A quiz covering essential JavaScript concepts.',
    },
    {
      id: 3,
      title: 'Frontend Development',
      description: 'Questions about HTML, CSS, and modern frontend frameworks.',
    },
  ];

  return (
    <div className="bg-gray-800 min-h-screen text-white p-6">
      <h1 className="text-3xl font-bold mb-6">Available Quizzes</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quizzes.map((quiz) => (
          <div
            key={quiz.id}
            className="bg-blue-700 p-4 rounded-lg shadow-lg hover:shadow-xl"
          >
            <h2 className="text-xl font-semibold mb-2">{quiz.title}</h2>
            <p className="mb-4">{quiz.description}</p>
            <Link
              to={`/quiz/${quiz.id}`}
              className="bg-blue-500 hover:bg-blue-400 text-white py-2 px-4 rounded"
            >
              Start Quiz
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuizList;
