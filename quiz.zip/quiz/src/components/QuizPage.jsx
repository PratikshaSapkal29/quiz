import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const QuizPage = () => {
  const [questions] = useState([
    { id: 1, question: 'What is React?', options: ['Library', 'Framework', 'Language', 'Tool'], correct: 'Library' },
    { id: 2, question: 'What is JSX?', options: ['JavaScript', 'XML', 'JavaScript + HTML', 'JSON'], correct: 'JavaScript + HTML' }
  ]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const navigate = useNavigate();

  const handleAnswer = (selectedOption) => {
    if (selectedOption === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      navigate('/score-summary', { state: { score: score + 1, total: questions.length } });
    }
  };

  return (
    <div className="min-h-screen bg-gray-800 text-white flex flex-col items-center justify-center">
      <h1 className="text-2xl font-bold mb-6">{questions[currentQuestion].question}</h1>
      {questions[currentQuestion].options.map((option, index) => (
        <button
          key={index}
          className="bg-blue-500 hover:bg-blue-400 text-white py-2 px-4 m-2 rounded"
          onClick={() => handleAnswer(option)}
        >
          {option}
        </button>
      ))}
    </div>
  );
};

export default QuizPage;
