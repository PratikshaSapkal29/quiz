import React from 'react';
import { useLocation } from 'react-router-dom';

const ScoreSummary = () => {
  const location = useLocation();
  const { score, total } = location.state || { score: 0, total: 0 };

  return (
    <div className="min-h-screen bg-gray-800 text-white flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-6">Quiz Completed!</h1>
      <p className="text-xl">You scored {score} out of {total}.</p>
    </div>
  );
};

export default ScoreSummary;
